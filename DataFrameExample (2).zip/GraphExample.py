import pandas as pd

#pip install matplotlib
import matplotlib.pyplot as plt

emp = {'eid':[1,2,3,4],'name':['Raman','Jatin','Divya','Vidhi']}
e = pd.DataFrame(data=emp)

print(e)

#add new column
#size should be same
sal = [455555,33333,44455,33455]

e['sal']= sal

#default graph is line chart
#e.plot()

#e.plot(kind='bar')
#e.plot(kind='box')

#e.plot(kind='bar',subplots=True)


e.plot(kind='bar',subplots=True,layout=(1,2))

plt.show()


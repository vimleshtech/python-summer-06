import pandas as pd

emp = {'eid':[1,2,3,4],'name':['Raman','Jatin','Divya','Vidhi']}
e = pd.DataFrame(data=emp)

print(e)

#add new column
#size should be same
sal = [455555,33333,44455,33455]

e['sal']= sal

print(e)

####remove column
ne = e[['name','sal']]
print(ne)


#####convert dataframe to list or array
x = e.values
print(x)

#read all rows and selected columns
print(x[:,1:3]) #read all rows and 1st and 2nd col


#read all columns and selected rows
print(x[1:3,:])

#filter rows and columns : show selected rows and columns
print(x[1:3,0:2])  #[row index,col index]

###fitler the rows with condition 

o = e[e['eid']>3]
print(o)
































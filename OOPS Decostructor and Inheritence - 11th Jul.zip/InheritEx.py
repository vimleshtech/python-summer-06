class calA:
     def add(s,a,b):
          print(a+b)

     def mul(s,a,b):
          print(a*b)

     def div(s,a,b):
          print(a/b)
          
class calB(calA):
     def tax(s,amt):
          if amt>100:
               print('taxable income')
          else:
               print('nont-taxable')

class calC(calB):
     def test(s):
          print('test')

#multiple 
class A:
     def a(s):
          print(s)

class B:
     def b(s):
          print(b)
class C(A,B):
     def c(s):
          print(c)


#
def a():
     print('a')

def a(a):
     print('b')

a(1)


          
          
c = calC()
c.add(11,3)
c.mul(33,5)
c.tax(4455)
c.test()






             

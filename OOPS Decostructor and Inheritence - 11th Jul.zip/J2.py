class emp:

     def input(s):
          s.id = input('enter id :')
          s.sal = int(input('enter sal :'))
          

     def cal(s):
          s.ysal  = s.sal*12
                          

     def show(m):
          print(m.id)
          print(m.ysal)

o = []
for x in range(4):
     ob = emp()
     ob.input()
     ob.cal()
     o.append(ob)


#print(o)
for d in o:
     d.show()


     

     
     

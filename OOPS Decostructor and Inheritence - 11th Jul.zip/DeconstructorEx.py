class cal:
     def add(s,a,b):
          print(a+b)

     def __del__(s):
          print('object is removed')

     def __init__(s):
          print('object is allocated')
     def sub(s,a,b):
          print(a-b)


c = cal()
c.add(11,3)
c.sub(44,5)
c.__init__()
del c
#c.add(11,3)

     
          

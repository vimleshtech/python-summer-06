'''
List Example:
List : collection of data or values

-List index start from 0
-Last index of list will be len -1




a =[111,33,444,5566]

print(a)

#len
print(len(a)) #count

print(a[0])
print(a[-1]) #read from right / last value 

print(a[3]) #last value

#append : add new value at last index
a.append(100)
print(a)

#pop : remove from last
a.pop()
a.pop()

print(a)

#max
print(max(a))

#min
print(min(a))

#sum
print(sum(a))


#insert : at new value at given index
a.insert(1,100)
print(a)


#remove : find value and remove if match
print(a.remove(100))
print(a)

#sort: arrange data in asc or desc order
a.sort()
print(a)


#D1: WAP to input the marks of 10 students in an array of integers and
#display the marks

a=[44,34,35,45,6,7,5,33,5,6]
print('marks of 10 students are:',a)
'''
'''
#WAP to search how many times a number is present in an array
a=[10,10,233,10,455,55,455]
c =0
z=int(input('enter the no.'))
for i in range(0,len(a)):
    if z == a[i]:
        c = c+1

print(c)
'''


'''

#WAP to subtract two arrays of the same size.
a=[10,11,12,244]
b=[10,67,23,252]
print(a[0]-b[0],a[1]-b[1],a[2]-b[2],a[3]-b[3])


#or
a=[11,222,44,555,6]
b=[1,2322,454,5355,6]

for i in range(0,len(a)):
    print(a[i] - b[i])
    
'''

a = 11 #here a is variable and 11 is data or value
b =545 #here b is variable and 545 is data or value 

c =a+b  #expression 
print(c) #show to console
print('sum of two numebrs :',c)


'''
fn ='nitin 221345%%%###'
print(fn)

ln ="sklhsfsgh%$#%"
print(ln)

d ="Raman's friend is Hema"
print(d)
'''



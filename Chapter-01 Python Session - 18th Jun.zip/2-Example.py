
fn = input('enter first name :')
ln = input('enter last name :')

name =fn+ln
print('name is :',name)


#WAP to take mark in 5 subjects and show to total and average
a = input('enter num  :')
b = input('enter num  :')
c = input('enter num  :')
d = input('enter num  :')
e = input('enter num  :')


#type casting / covnert one type to another type 
total = int(a) + int(b) + int(c) + int(d) + int(e)
avg = total/5

print('Total score is :',total)
print('Average score is :',avg)















#if condition
amt = int(input('enter data :'))
tax = 0

if amt>10000:
     tax = amt *.40 # 40% tax of amt
     print('test')
elif amt > 1000:
     tax = amt *.20 
elif amt>500:
     tax = amt *.10 
else:
     tax = amt*.05
     
     

total = amt+tax
print('total amt :',total)




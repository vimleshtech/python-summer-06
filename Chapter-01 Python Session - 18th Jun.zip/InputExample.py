#WAP to get sum and average of two input or number
n1 = int(input('enter data :'))
n2 = int(input('enter data :'))

n =n1+n2
a = n/2

print('addition of two numbers :',n)
print('average of two numbers :',a)


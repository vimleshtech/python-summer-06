#if condition
amt = int(input('enter data :'))
tax = 0

if amt>1000:
     tax = amt *.40 # 40% tax of amt
     print('test')
     

total = amt+tax
print('total amt :',total)




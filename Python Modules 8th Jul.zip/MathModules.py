import math #math is inbuilt package/library
import random
import time

print(math.pi)
print(math.pow(2,10))
print(math.factorial(6))
print(math.sqrt(9))


print(random.randint(1,10))
print(random.randint(1000,9999))
print(random.random())

t = time.localtime()
print(t)
print('year :',t.tm_year)
print('month :',t.tm_mon)
print('day :',t.tm_mday)
print('hour :',t.tm_hour)

print(t.tm_year,t.tm_mon,t.tm_mday)










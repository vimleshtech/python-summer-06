import os  #to get list of files and folder from given path 
import shutil #to copy or move the file from source to destination 

l = os.listdir(r'C:\Users\vkumar15\Documents')
print(l)


#print file one by one
for x in l:
     #print(x)
     if x.endswith('.txt'):
          print(x)
     
     

#count of all files
print(len(l))



##move/copy file
shutil.copy(r'C:\Users\vkumar15\Documents\Chapter-01 Python.txt',r'C:\Users\vkumar15\Desktop')
print('file is copied')









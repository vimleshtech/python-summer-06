#default mode is read 
f = open(r'C:\Users\vkumar15\Desktop\Chapter-01 Python.txt','r')

#print(f.read())#read all content

#print(f.readline()) #read first, line by line (one line at a time)
#print(f.readline()) #2nd 
#print(f.readline()) #3rd

#print(f.readlines()) #read and convert to list , every item of file will become one item of list
d =f.readlines()
f.close()

for r in d:
     print(r)

#row count
print(len(d))








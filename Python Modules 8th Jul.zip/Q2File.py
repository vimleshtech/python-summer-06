f = open(r'C:\Users\vkumar15\Desktop\out.txt','r')#read file

rows = f.readlines()
print(rows)
c =0
for r in rows:
    c= c+len(r)

print(c)

     

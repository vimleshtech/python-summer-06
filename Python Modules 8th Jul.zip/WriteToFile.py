f = open(r'C:\Users\vkumar15\Desktop\out.txt','w')

f.write('hi, this is test code\n')
f.write('bye\n')
f.write('test\n')
f.write('hi\n')
f.close()
print('file is saved')






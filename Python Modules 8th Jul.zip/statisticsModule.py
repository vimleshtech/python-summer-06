import statistics

a =[1,2,3,4,6]

print(statistics.mean(a)) #avg 
print(statistics.median(a)) #middle 

a =[1,2,3,4,6,7,1,2,1] #(3+4)/2
print(statistics.median(a))

print(statistics.mode(a)) 
print(statistics.variance(a))  #
print(statistics.stdev(a))  # sqrt of var.

#max-min = range
print(max(a) - min(a))



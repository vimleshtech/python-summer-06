import mysql.connector  as c
con = c.connect(host='localhost',user='root',password='root',database='pydata')

cur = con.cursor()  #to run sql command / statement

def read_data():
     cur.execute('select * from employee')

     out = cur.fetchall()
     #print(out)
     for r in out:
          print(r[0],r[1])
          

def write_data():
     i = input('enter id :')
     n = input('enter name :')
     g = input('enter gender :')
     s = input('enter sal :')
     st ="insert into employee(eid,name,gender,salary)values({},'{}','{}',{})".format(i,n,g,s)
            
     cur.execute(st)
     con.commit()
     print('data is saved')

write_data()
read_data()



     
     
     



class student:

     def __init__(self):
          self.rollno = 0
          self.name =''
          self.address =''
          self.city =''
          self.country =''

     def get_data(self):
          self.rollno = int(input('enter rollno:'))
          self.name = input('enter name:')
          self.address = input('enter address :')
          self.city = input('enter city :')
          self.country= input('enter country  :')
     def retroll(self):
          return self.rollno
     def dispdata(self):
          print('student details ...')
          print('name :',self.name,' rollno :',self.rollno,' city : ',self.city, ' country : ',self.country, ' address ',self.address)

          
l = []
#input
for x in range(5):
     o = student()
     o.get_data()
     l.append(o)

##sorting
for i in range(0,len(l)):
     for j in range(i+1,len(l)):
          if l[i].retroll() > l[j].retroll():
               temp  = l[i]
               l[i] = l[j]
               l[j] = temp


#print all
for o in l:
     o.dispdata()
     
          
     

a =[]
b =[]

for i in range(0,5):
    x = int(input('enter data :'))
    a.append(x)

for i in range(0,5):
    x = int(input('enter data :'))
    b.append(x)
    

print(a)
print(b)

#substruct
for i in range(0,len(a)):   #range(0,5) # 0 1 2 3 4 
    print(a[i] - b[i])
    

a =[11,222,333,444,1,1,1,2,3,4,5]

print('max =',max(a))
print('min =',min(a))
print('sum =',sum(a))
print('len =',len(a))

#sort
a.sort()
print(a)


#add new value at last
a.append(100)
print(a)


#pop
a.pop()
a.pop()
print(a)

#insert :at given position
a.insert(2,400)
print(a)


#remove by value
a.remove(400)
print(a)

#slicer
print(a[0:4]) #from 0 th index to 3rd index (<last index)


#iterate : read data one by one
print(a)

for x in a:
    print(x)
    








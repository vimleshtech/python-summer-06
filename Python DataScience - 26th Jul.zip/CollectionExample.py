##list
l =[11,222,344,555,2322,44]

print(type(l))

print(l*2)

for x in l:
    print(x)
    
##array
import numpy as np
x = np.array(l)
print(type(x))
print(x*2)

##
x = [[11,222,33],[44,555,66],[1,2,3]]

y =np.array(x)
print(y)
print(y.T)


##pandas
import pandas as pd

#row and col index , dataframe is table
x = pd.DataFrame()
print(x)
print(type(x))

##create dataframe from list

x = pd.DataFrame(data={'eid':[1,2,3,4],'name':['nitin','jatin','divya','xy'],'sal':[55,55555,33333,455555]})

print(x)
#print column name
print(x.columns)

#string : is object
#change column name
x.columns=['ecode','ename','esal']

print(x)


#show shape (size)
print(x.shape)


#add new colum in dataframe
x['gender']=['male','male','female','male']

print(x)



#show selected column
print(x['ename'])



#show multiple selected name
print(x[['ename','gender','ecode']])



#show row from top
print(x.head(2))

#show from buttom
print(x.tail(2))



#search or filter
y = x[x['gender']=='male']
print(y)

#tbl[ tbl['col'] > 12333 ] 

##show the infor about dataframe
print(x.info())


#show describe / show stats
print(x.describe())

'''
            ecode           esal
count    3.000000       3.000000      #row count
mean   192.000000  181481.000000      #average  
std    168.020832  237614.966759      #sqrt for var (var is difference for mean)
min     11.000000   33333.000000      #lowest value
25%    116.500000   44444.000000      #first q1
50%    222.000000   55555.000000   
75%    282.500000  255555.000000
max    343.000000  455555.000000

'''

















































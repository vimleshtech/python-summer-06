import re

s = input('enter string :')
o = re.match('(.*) are (.*)',s)

#print(o.groups())
#print(o.group(1))
#print(o.group(2))

if o:
     print('are is match')
else:
     print('not match')
     
#validate email id
email = input('enter email :')
o = re.search('@gmail.com$',email)
#o = re.match('(.*)@gmail.com',email)

if o:
     print('valid gmail account')
else:
     print('invalid gmail account')
     


     














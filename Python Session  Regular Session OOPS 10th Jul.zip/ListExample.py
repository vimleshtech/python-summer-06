sales = []


for x in range(10):
     s = int(input('enter data :'))
     sales.append(s)


print(sales)
print(sum(sales))



     

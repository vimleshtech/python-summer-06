#class
class emp:

     #function 
     def test(s):
          
          print('in test ',s)
          s.n1 = int(input('enter data :'))
          s.n2 = int(input('enter data :'))
          
     def __init__(s):
          print('object is created')
          s.n1 =0
          s.n2 =0
          s.name =''
          
     def add(a):
          
          print('in add ',a)
          n = a.n1+a.n2
          print(n)


#create object
o  = emp()
o.add()
print(o) #print address of object
o.test() #call to function
o.add()


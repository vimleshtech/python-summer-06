
i =1
while i<11:
     print(i)
     i=i+1

#print in same line
i =1
while i<11:
     print(i,end=',')#end='' : don't chage line 
     i=i+1
     

#print in reverse
i =10
while i>0:
     print(i)
     i =i-1


#print table of 4
i =1
while i<=10:
     print(i*4)
     i =i+1


#wap to get sum of all even and odd numebrs between 1 to 30
se = 0
so = 0
i =1
while i<=30:
     if i% 2==0: #if no is even
          se =se+i
     else:
          so = so+i

     i =i+1

print('sum of all even no :',se)
print('sum of all odd no :',so)



#wap to print series between two given no
sn = int(input('enter data :'))
en = int(input('enter data :'))

while se<=en:
     print(se)
     se =se+1




     
     



          
     








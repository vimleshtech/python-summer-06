'''
1234
1234
1234
'''


for r in range(1,4):
     for c in range(1,5):
          print(c)
     

for r in range(1,4):
     for c in range(1,5):
          print(c,end='')
     
     
for r in range(1,4):
     for c in range(1,5):
          print(c,end='')
     print()#new line 
          
          

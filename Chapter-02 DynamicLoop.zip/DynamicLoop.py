#example

while True:
     ch = input('enter 1 for add. 2 for sub 0 for exit')
     if ch =='1':
          a = int(input('enter data :'))
          b = int(input('enter data :'))
          c =a+b
          print(c)

     elif ch=='2':
          a = int(input('enter data :'))
          b = int(input('enter data :'))
          c =a-b
          print(c)


     elif ch=='0':
          break

     else:
          print('ivaild input , pls try again !!!')
          
          
     

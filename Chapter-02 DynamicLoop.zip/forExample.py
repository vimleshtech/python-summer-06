#range(1,10):  from 1 to 9  #default incrementer is 1
#range(1,10,1) : from 1 2 3 4 ... 9
#range(1,10,2) : 1 3 5 7 9

for r in range(1,100): #from 1 to 99
     print(r)



for r in range(1,100,2):
     print(r)

#in reverse
for i in range(10,0,-1): #from 10 to 1
     print(i)
     
     
     


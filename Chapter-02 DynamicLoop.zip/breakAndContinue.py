#break
for i in range(1,10):
     if i%3 ==0:
          break #stop the loop
     
     print(i)
     

#continue
     
for i in range(1,10):
     if i%3 ==0:
          continue
     
     print(i)
     
     
     
     
     

'''
a=int(input('enter the salary'))
b=a*.10
print('hra is:',b)
c=a*.15
print('da is:',c)
'''
'''
#wap to input 5 subject marks and calc the division
a=int(input('enter marks of subjet 1:'))
b=int(input('enter marks of subjet 2:'))
c=int(input('enter marks of subjet 3:'))
d=int(input('enter marks of subjet 4:'))
e=int(input('enter marks of subjet 5:'))
z=(a+b+c+d+e)/5
if z>=60:
    print('first division')
elif z>=50:
    print('second division')
elif z>=40:
    print('third division')
else:
    print('fail')
'''
'''

#wap for calculating different electric meter charges
a=int(input('enter the no. of units:'))
if a>=300:
    print('the total cost is:',a*.60)
elif a>=200:
    print('the total cost is:',a*.50)
else:
    print('the total cost is:',a*.40)
'''
'''
#wap to find out the sum and average of all the no.s wihim the given range.
a=int(input('enter the starting no.'))
b=int(input('enter the ending no.'))
s =0
s1=0

for r in range(a,b):
    s =s+r
    s1 =(s+r)/(b-a)

print(s,s1)

'''
a=int(input('enter the first data:'))
b=int(input('enter the last data:'))
for i in range(a,b):
    print()


















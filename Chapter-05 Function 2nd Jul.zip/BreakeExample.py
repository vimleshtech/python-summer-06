for i in range(10):
     print(i)
     

print('---')
#break: stop to loop when number is divided by 4
for i in range(1,10):
     if i % 4 ==0:
          break
     print(i)

print('---')
#continue : skip the current iteration and resume from next
for i in range(1,10):
     if i% 3 ==0:
          continue

     print(i)

#1 2 4 5 7 8 2     
     
          

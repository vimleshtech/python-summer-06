import mylib

mylib.wel()
mylib.add(111,3)


#or 
from mylib import *
add(11,3)
wel()

#or
from mylib import add,mul

add(11,3)

#or
import mylib as m
m.wel()






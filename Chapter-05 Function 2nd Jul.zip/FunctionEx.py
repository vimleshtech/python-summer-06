o =11 #can be acess from anywhere / gloabl 
#function
#no argument no return
def wel():
     print('welcome...test')


#no argument with return
def getNum():
     a = int(input('enter data:'))
     b = int(input('enter data:'))
     return a,b

#argument with no return
def add(a,b):
     c =a+b
     print(c)
     
     
#argument with return
def sub(a,b):
     return a-b

#with default argument
def addNum(a,b=0,c=0,d=0): #b,c,d are optional argument 
     print(a+b+c+d)
     

##
def mul(*a): #argument type is tuple
     global m #global 
     m =1
     o =1 #local variable
     for x in a:
          o *=x
          
          
     print(o)
     
#call to function
'''
wel()
wel()

x,y = getNum()
print(x+y)


x,y = getNum()
print(x-y)


add(11,22)
add(11,220)


x = sub(11,3)
print(x)


addNum(1)
addNum(1,3)
addNum(1,33,54)
addNum(1,44,55,333)
'''


mul(21,33,45,66,74,34)
mul(21,33,45,66,74,34,343,33,4,5)
print(o)
print(m)



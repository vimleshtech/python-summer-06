from tkinter import *

window = Tk()

title = Label(text='This is test GUI Programing!!!')
title.pack()


lfn = Label(text='First Name')
lfn.pack()

tfn = Entry()
tfn.pack()

lln = Label(text='Last Name')
lln.pack()


tln = Entry()
tln.pack()

msg = Label(text='')
msg.pack()

def action():
     
     fn = tfn.get()
     ln = tln.get()
     
     #print('you have clicked on button')
     #print('Full name is :',fn,' ',ln)

     msg.configure(text='Full name is : '+fn+' '+ln)
     
     
     
           
btn = Button(text='Submit',command=action)
btn.pack()



window.mainloop()




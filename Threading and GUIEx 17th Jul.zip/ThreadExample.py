import time
import threading

def process1():
          
     for x in range(5):
          print(x)
          #time.sleep(3)          
     
def process2():
     for i in range(10,15):
          print(i)
          

#process1()
#process2()

t1 = threading.Thread(target=process1,name='task1')
t2 = threading.Thread(target=process2,name='task2')

t1.start() #start is inbuilt function which invokes to custom function which is bind with thread process
t2.start()


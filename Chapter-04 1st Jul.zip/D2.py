
marks = [] #empty list
for i in range(10): #from 0 to 9
     d = int(input('enter mark :'))
     marks.append(d)

nd = int(input('enter value to find :'))
counter =0
for x in marks:
     if x ==nd:
          counter+=1

print(counter)
     
     

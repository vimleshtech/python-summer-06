
from tkinter import *

o = Tk()

def ab():
     print('you have clicked on button')
     
btn = Button(text='Click',command=ab)
btn.pack()

o.mainloop()


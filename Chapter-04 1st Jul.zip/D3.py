
a = [] #empty list
for i in range(4): #from 0 to 9
     d = int(input('enter mark :'))
     a.append(d)


b = [] #empty list
for i in range(4): #from 0 to 9
     d = int(input('enter mark :'))
     b.append(d)


#sub
for i in range(4):
     print(a[i] - b[i])
     

a = int(input('enter nu :'))
b = int(input('enter nu :'))
c = int(input('enter nu :'))
d = int(input('enter nu :'))

a= a**3
b= b**3
c= c**3
d= d**3

if a+b+c==d:
     print('condition is match')
else:
     print('not match')
     
          

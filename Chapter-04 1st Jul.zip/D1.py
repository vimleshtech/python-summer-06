
marks = [] #empty list

#range(10)  #from 0 till 9  , default incrementer is 1
#range(0,10)  #from 0 till 9
#range(0,10,1)  #from 0 till 9
#range(0,10,2)  #from 0 till 9
#0 2 4 6 8          
for i in range(10): #from 0 to 9
     d = int(input('enter mark :'))
     marks.append(d)

#print
print(marks)

     
     

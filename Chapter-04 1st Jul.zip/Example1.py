#declare variables 
a =11
b =55
c =a*b
print(c)


#input data from user
a = input('etner data ') #default input type is str
b = input('etner data ')
print(type(a))
print(type(b))
#type casting : convert str to int
c =int(a)+ int(b)
print(c)





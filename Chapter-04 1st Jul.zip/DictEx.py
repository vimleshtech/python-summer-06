a ={'a':'alpha',1:'one',2:[111,'raman',555]}

print(a)
print(a[1])
print(a.items())
print(a.keys())

for k in a.keys():
     print(a[k])

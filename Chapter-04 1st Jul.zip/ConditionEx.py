a = int(input('enter data :'))
b = int(input('enter data :'))

if a>b:
     print('a is greater')
else:
     print('b is greater')
     

##
a = [11,222,44,55,666,333,55,333]
#search given value is present in list or not
n = int(input('enter nu :'))

if n in a:
     print(n,' is match')
else:
     print('is not match')
     







     








     



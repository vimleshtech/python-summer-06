a =(11,22,34,55,66)
print('max ',max(a))
print('min ',min(a))
print('sum ',sum(a))
print('len ',len(a))

#slicer
print(a[0]) #print first item
print(a[0:3]) #print fro 0 to 2
print(a[:3]) #print fro 0 to 2

#read from right
print(a[-1])


#print in reverse
print(a[::-1])


#weekdays
wd =('mon','tue','wed','thu','fri')

today = input("enter today's day ")
if today in wd:
     print('weekday')
else:
     print('weekend or other day')




     


     













a = [] #empty list
for i in range(12): #from 0 to 9
     d = int(input('enter sales amt :'))
     a.append(d)


avg = sum(a)/len(a)

for x in a:
     if x>avg:
          print(x)
          


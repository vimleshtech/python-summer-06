import numpy as np

#aragne

d = np.arange(1,10)
print(d)

d = np.arange(1,10,3) #show data
print(d)


m= d*2
print(m)

##shape
print(type(m))
print(m.shape)

#convert list to array
x =[[1,2,3],[4,5,6],[6,7,8]]
o = np.array(x)
print(o)
print(o.shape)

#tranpose
print(o.T)



y =[[11,12,3],[44,5,60],[26,7,8]]
n = np.array(y)


print(o)
print(n)

print(np.subtract(o,n))
print(np.divide(o,n))
print(np.multiply(o,n))












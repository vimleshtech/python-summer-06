import pandas as pd

#create empty dataframe
df = pd.DataFrame()
print(df)

#index: rows
#column: header


#create dataframe from list
eid = [11,20,44,55,9]
ename = ['Raman','Jatin','Divya','Pooja','Rohit']
age =[21,31,28,29,19]
gender=['m','m','f','f','m']
exp = [2,4,1,6,7]
sal = [25000,48000,20000,80000,72000]



df = pd.DataFrame(data={'emp no':eid,'name':ename,
                        'age':age,'sex':gender,'exp':exp,'sal':sal})
print(df)


print(df.columns)
print(df.info())

#
print(df.shape)

#return top given rows
print(df.head(2))
#from buttom
print(df.tail(2))


#distribuation / group by
print(df.groupby('sex').size())


print(df.groupby('sex').sum()['sal'])

print(df.groupby('sex').max()['sal'])


print(df.groupby('sex').min()['sal'])


##order by
print(df.sort_values('sal',ascending=True))
print(df.sort_values('sal',ascending=False))


print(df.corr())



































                  










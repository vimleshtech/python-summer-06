kaggle.com

Python DataScience and ML
=======================================
DataScience vs  ML  vs AI 
-------------------------------
DataScience  : DataStruture -> DataMining/Extraction->Data Visualization -> ML -> AI
ML : Machine Learning
   : Maths Algo
		(corr, regression , predict, supervised learning, etc.)

AI : 


-> numpy : is numerical python to manage n dimenssion data (ndarry)
=================================
numpy is module in python which need to install 

-open the cmd
$cd path_path/script
$pip install numpy 
 

-> pandas : is module which manage the dataframe (table)
=================================
$pip install pandas


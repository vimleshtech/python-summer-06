import pandas as pd



#create dataframe from list

cc  = [1200,1400,1100,1000,700]
mpg = [20,16,22,23,28]


df = pd.DataFrame(data={'cc':cc,'mpg':mpg})
print(df.corr())


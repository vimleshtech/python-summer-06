#pandas

import pandas as pd

#create empty dataframe 
df = pd.DataFrame()
print(df)

## convert dict to dataframe
d ={'eid':[1,2,23,4,5],
       'name':['raman','jatin','divya','ayush','monika'],
       'gender':['male','male','female','male','female'],
       'sal':[45000,67000,23000,89000,110000]}
print(d)

emp = pd.DataFrame(data=d)
print(emp)


#get columns
print(emp.columns)

#show shape
print(emp.shape)

#show top given rows
print(emp.head(3))

#show data from buttom
print(emp.tail(2))

#show select column
print(emp['name'])

print(emp[['name','sal']]) #show multiple columns


##shwo structure data frame
print(emp.info())

##sort data by salary
print(emp.sort_values('sal',ascending=True))
print(emp.sort_values('sal',ascending=False))

print(emp.sort_values('name',ascending=True))

#write data to csv/excel
#emp.to_csv('emp.csv')

#
d = pd.read_csv('emp.csv')
print(d)


































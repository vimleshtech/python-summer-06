import numpy as np

x = np.arange(1,10) #generate the number from 1 to 9
print(x)

x = np.arange(1,10,.3) #generate the number from 1 to 9
print(x)

#convert list to array
m = [111,222,34,55,2,45]
print(m)
print(m*2)

y = np.array(m)
print(y)
print(y*2)


#shape
print(y.shape)

##reshape
y = np.array(m).reshape(-1,2)
print(y)
print(y.shape)

##
z = np.zeros(10)
print(z)

o = np.ones(10)
print(o)


#calculation
a= [[1,2,3],[1,23,30],[11,25,3]]
b= [[1,2,3],[1,23,30],[11,25,3]]

x = np.array(a)
y = np.array(b)

print(np.subtract(x,y))
print(np.add(x,y))
print(np.multiply(x,y))


###

z = x*2
print(z)

##data type
print(type(z))

#
x =[111,22,34,4555]
y = np.array(x)
print(y)

y = np.array(x,dtype=float)
print(y)












      


















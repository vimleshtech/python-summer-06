'''
File: read, write, and append operations:

open(path,mode)
  path : physical location of file
  mode :
         r : read
         w : write (create new file if not exist, and overwrite the file  already exist
         a : append

read() : read all content from file
readline() : read first line from file (line by line)
realines(): read all content from file and convert to list
             -ever line of file will become one item of list
             ['line1 ','line 2'..]
write(str)  : write content to file
close() : save and close the file
'''

#create new file
f  = open('output.txt','w')

name = input('enter name:')
email = input('enter email:')
rno = input('enter rno:')

f.write(name+"\n")
f.write(email+"\n")
f.write(rno+"\n")



f.close() #save file









             

         
  

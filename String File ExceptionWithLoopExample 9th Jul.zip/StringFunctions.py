'''
String Handing / Functions:

len()   : return count of chars including space
upper() : convert to upper case
lower() : convert to lower case
title()  : convert to proper case
           this is  = This Is 
strip()  : remove leading sapce/ before and after sapce

list()   : convert string to list, break char by char
          this is = ['t','h','i','s',' ','i','s']
replace() : find old/existing char/word and replace with new
count()   : find the given char/word and return the occurance
split()   : break string by given seperator 

isdigit() : return boolean
islower() : return boolean
isupper() : return boolean
endswith()  :  compare last char/word
ord()       : convert char to ascii
chr()      : convert numeric to char 

'''

a = input('enter string :')
print(len(a))
print(a.upper())
print(a.lower())
print(a.title())
print(a.strip())

o = list(a)
print(o)

print(a.replace('is','are'))

print(a.count('i'))

#this is test code = ['this','is','test','code']
s = a.split(' ') #split by space by default
print(s)

for w in s:
     print(w)
     

#get position of is
for i in range(len(s)):
     if s[i] =='is':
          print(' is is match at ',i)
          
     
if a.isdigit():
     print('number')
else:
     print('not number')



if a.isupper():
     print('in upper')
else:
     print('not in upper')

  
if a.islower():
     print('in lower')
else:
     print('not in lower')



if a.endswith('is'):
     print('ending with is')
else:
     print('not ending with is')

          

        


     




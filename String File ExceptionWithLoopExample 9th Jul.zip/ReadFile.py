#default mode is r
a = open('output.txt','r')
#print(a.read())
#print(a.readline())
#print(a.readline())

d = a.readlines()
print(type(d))

print(d)
for r in d:
     print(r)

a.close()







'''
Variable
Operator
Condition
Input and output
Loop                 **
Collection : List, Tuple , Dict, Set **
String Handling
File Handling : read and writer


exception handling **
--------------------------
exception : is runtime error
handling  : tackle the error when this will occur

Advantage of exception handling:
-Prevent the code from failure due to few error
-Show customize error message
-Write the error log 

'''

a = int(input('enter data :'))
b = int(input('enter data :'))

try:

     #raise : custom or user defined error
     if b<0:
          er = ZeroDivisionError('divisor cannot be less than 0')
          raise er
     
     n =a/b
     print(n)
     
except NameError as e:
     print(e)
except TypeError as e:
     print(e)
except ZeroDivisionError as e:
     print(e)
except IndexError as i:
     print(i)
except:
     print('error')
     #pass #continue the code 
finally:  #is optional which may or may not implemented, but this block will execute always if present
     print('end of program')
     
c = a+b
print(c)




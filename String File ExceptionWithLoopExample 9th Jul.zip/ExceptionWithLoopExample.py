
while True:

     try:
          a = int(input('enter data :'))
          b = int(input('enter data :'))

          if a<1 or b<1:
               continue    #skip the current iteration and resume from next

          c = a/b
          print(c)
          break #stop the loop
     except:
          print('given data is not correct, plz try again')
          

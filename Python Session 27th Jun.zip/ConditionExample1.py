a = int(input('enter num :')) #default input type is str 
b = int(input('enter num :'))
c = int(input('enter num :'))
d = int(input('enter num :'))

if a**3+b**3+c**3 == d**3:
     print('condition is match')
else:
     print('condition is not match')
     
     


print(ord(' '))
a ='9'
print(ord(a))






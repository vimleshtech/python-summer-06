#while loop
i =1 #init 
while i<10: #condition
     print(i)
     i =i+1 #incrementer
     
     

#for loop
for x in range(1,10):
     print(x)
     
##
a = 'this is test code'
for c in a:
     print(c)
     #print(c,end='') #don't change line 


#
name  = input('enter name :')
print(name)
col = name.split()
print(col)

#iterate
for w in col:
     print(w)
     


     











     

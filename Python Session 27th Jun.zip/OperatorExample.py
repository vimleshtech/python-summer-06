a = 11
b =44
c =a+b
print('sum =',c)

a = 11
b =44
c =a-b
print('sub =',c)


a = 11
b =44
c =a*b
print('mul =',c)

a = 2
b =10
c =a**b
print('2 pow 10 =',c)


a = 23
b =10
c =a/b
print('div in float =',c)

c =a//b
print('div in int =',c)

c =a%b
print('mod =',c)













